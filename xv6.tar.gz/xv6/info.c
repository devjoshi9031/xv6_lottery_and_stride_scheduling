#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "stat.h"


int
main(int argc, char *argv[])
{
	
	if(argc < 2) {
		printf(1, "Please enter 1,2 or 3 : Incorrect format\n");
		exit();
	}

	int i = atoi(argv[1]);

    if(i == 1){
		printf(2, "Count of processes in the system is : %d\n", mycall(i));
		exit();
	}
	 else if(i == 2){
		printf(2, "Total number of system calls made by the current process: %d\n", mycall(i));
		exit();
	}
	 else if(i == 3){
		printf(2, "Count of memory pages that the current process is using: %d\n", mycall(i));
		exit();
	}
	else{
		exit();
	}

}